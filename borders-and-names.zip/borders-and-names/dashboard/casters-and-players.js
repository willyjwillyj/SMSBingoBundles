// You can access the NodeCG api anytime from the `window.nodecg` object

// Or just `nodecg` for short. Like this!:
const state = nodecg.Replicant("state");
const players = ["player1", "player2","player3","player4"];
const casters = ["caster1", "caster2","caster3","caster4"];
const attributes = ["pronouns","name","discordID"];
const targets = ["-pronouns","-name","-id"];



function updateNames(){
    let playerData = [];
    let casterData = [];
    for (let i = 0; i < 4; i++){
        let result = "";
        let item = {

        }
            for(let ii = 0; ii < 3; ii++){
                const thisTarget = document.getElementById(players[i]+targets[ii]);
                result = thisTarget.value;
                if (ii == 0){
                    item.pronouns = result;
                }
                if (ii == 1){
                    item.name = result;
                }
                if (ii == 2){
                    item.discordID = result;
                }
            }
        if (item.name != ""){
        playerData.push(item);
        }
    }

    for (let i = 0; i < 4; i++){
        let result = "";
        let item = {

        }
            for(let ii = 0; ii < 3; ii++){
                const thisTarget = document.getElementById(casters[i]+targets[ii]);
                result = thisTarget.value;
                if (ii == 0){
                    item.pronouns = result;
                }
                if (ii == 1){
                    item.name = result;
                }
                if (ii == 2){
                    item.discordID = result;
                }
            }
        if (item.name != ""){
        casterData.push(item);
        }
    }
    let checkbox = document.getElementById("expander");

    state.value = {
        players:playerData,
        casters:casterData,
        expand:checkbox.checked
    }
}

function prefillNames(){
    for (let i = 0; i < state.value.players.length; i++){
        const thisItem = state.value.players[i];
            for(let ii = 0; ii < 3; ii++){
                const thisTarget = document.getElementById(players[i]+targets[ii]);
                if (ii == 0){
                    thisTarget.value = thisItem.pronouns;
                }
                if (ii == 1){
                    thisTarget.value = thisItem.name;
                }
                if (ii == 2){
                    thisTarget.value = thisItem.discordID;
                }
            }
    }
    for (let i = 0; i < state.value.casters.length; i++){
        const thisItem = state.value.casters[i];
            for(let ii = 0; ii < 3; ii++){
                const thisTarget = document.getElementById(casters[i]+targets[ii]);
                if (ii == 0){
                    thisTarget.value = thisItem.pronouns;
                }
                if (ii == 1){
                    thisTarget.value = thisItem.name;
                }
                if (ii == 2){
                    thisTarget.value = thisItem.discordID;
                }
            }
    }
    let checkbox = document.getElementById("expander");
    checkbox.checked = state.value.expand;
}