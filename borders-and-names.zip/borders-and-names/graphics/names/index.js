function processUpdate(arg0) {
    //Input:
    //arg0: value of the replicant. Ths contains all of the data that we will need here 
    //Remove the nodes from the previous update
    
    const toDestroy = document.getElementById("graphic");
    toDestroy.remove();
    //Add nodes for the next update
    //Define a const to be the place where we are adding the new nodes too
    const root = document.createElement("div");
    root.id = "graphic";
    
    //5 nodes
    //1 - 4 players
    //caster box
    const players = arg0.players;
    const casters = arg0.casters;
    const expandCaster = arg0.expand;
    //define the charactaristics of each of these under IDs in the styles.css (important here would be the left and top styles, everything here will be a flexbox and positioned absolutely under the body)
    // Create player 1 box (function call)
    if (players.length >= 1){
        const player1 = buildPlayerBox(players[0],"player1","big");
        root.appendChild(player1);
    }
    // Create player 2 box (function call)
    if (players.length >= 2){
        const player2 = buildPlayerBox(players[1],"player2","big");
        root.appendChild(player2);
    }
    // Create player 3 box (function call)
    if (players.length >= 3){
        const player3 = buildPlayerBox(players[2],"player3","big");
        root.appendChild(player3);
    }
    // Create player 4 box (function call)
    if (players.length >= 4){
        const player4 = buildPlayerBox(players[3],"player4","big");
        root.appendChild(player4);
    }
    // Create caster box (function call)
    const casterBox = buildCasterBox(casters, expandCaster);
    root.appendChild(casterBox);
    //Add the players box and caster box to the DOM
    
    const trueRoot = document.getElementsByTagName("body")[0];
    trueRoot.append(root)
    //end procedure

}

function buildPlayerBox(arg0, arg1, arg2){
    console.log("started");
    //Goal of this is to build a player box and then return that player to the caller
    //The caller will handle things like adding the player box to the dom, it is easier that way
    //Input: 
    //First argument: input a single object that defines the charactaristics of that specific item
    //Second argument: input an ID that will be used in the styles.css to give the position attributes of the first div
    //Third argument: input a class that will be assigned to all of the objects within that class, basically will just be 3 things, either "big" for a runner, or "small-1-wide" for a single width caster or "small-2-wide" for a double width caster or something similar to that which will define the box size and the font sizes (I need to figure out how to properly use multiple classes, or maybe somehow concat the names together to make a combined thing since both texts will use the span tag)
    const pronouns = arg0.pronouns;
    const name = arg0.name;
    const discordID = arg0.discordID;
    const elementID = arg1;
    const elementClass = arg2;
    //give that class to all of the elements in the div, will be 

    //Start by creating an article that will contain the whole scope of things in this item
    const playerRoot = document.createElement("div");
    playerRoot.classList.add(elementClass)
    //Article will contain 3 subcomponents. Each subcomponent should be defined as a positioned div at position (0,0) and taking up size 100% 100%. Also make it a flexbox so that the things in them will be centred, will make things easier later for things like keeping the names in the right spot.
    //These are all small enough so I dont think making them subroutine calls is necessary at this point. Can reconsider this later if it is neccesary

    //Component 1: iframe to contain the reactive component. This will be something I need to learn hwow to do later so it may tak ea while to get down, and will probably be the last thing I make for this section
    const iframeRoot = document.createElement("section");
    iframeRoot.classList.add(elementClass);
    playerRoot.appendChild(iframeRoot);
    const iframe = document.createElement("iframe");
    if (discordID != ""){
    iframeRoot.appendChild(iframe);
    }
    const src = "https://reactive.fugi.tech/individual/" + String(discordID);
    iframe.setAttribute("src",src);
    //Component 2: text box to contain the person's name. A name is made up of 2 span tags, on for the pronouns and one for the person's name, and will need to be colored accordingly. 
    const nameRoot = document.createElement("section");
    nameRoot.classList.add(elementClass);
    playerRoot.appendChild(nameRoot);
    const nameContainer = document.createElement("div");
    nameContainer.classList.add("textContainer");
    nameContainer.classList.add(elementClass);
    playerRoot.id = elementID;
    nameRoot.appendChild(nameContainer);
    const pronounObject = document.createElement("span");
    pronounObject.innerHTML = pronouns;
    pronounObject.id = (elementID+"Pronouns");
    pronounObject.classList.add(elementClass+"Pronouns");
    const nameObject = document.createElement("span");
    nameObject.innerHTML =name;
    nameObject.id = (elementID+"Name"); 
    nameObject.classList.add(elementClass+"Name");

    nameContainer.appendChild(pronounObject);
    nameContainer.appendChild(nameObject);

    //Component 3: background. Defined in style guide as black with 60% alpha. Trivial
    const background = document.createElement("section");
    background.classList.add(elementClass);
    background.classList.add("speakerbg");
    playerRoot.appendChild(background);
    //Attatch each of these componenes to the root node

    //return the root node
    return playerRoot;
}

function buildCasterBox(arg0, arg1){
    //caster boxes will always be the same size which makes this kinda convenient.
    //input:
    //First argument: an array of objects to add. Each object will have a player name, pronouns, and discord ID for the reactive iframe
    //Second argument: boolean id to define whether or not a item will get expanded in the 3 player layout
    const casters = arg0
    const expandCaster = arg1;
    //Create a div that will contain the whole scope of things in this item
    const casterRoot = document.createElement("div");
    casterRoot.id = "casters"
    //create one or two rows for the caster box. we will decide how many based on the length of the array of objects that represent the casters. 
    //insert the rows intp the dom as a child of the div
    const boxRow1 = document.createElement("div");
    const boxRow2 = document.createElement("div");
    boxRow1.classList.add("caster-container-row");
    boxRow2.classList.add("caster-container-row");
    casterRoot.appendChild(boxRow1);
    if (casters.length > 1){
        casterRoot.appendChild(boxRow2);
    }
    
    //Switch statement (if/else chain if im a lazy prick)
    //switch statement will be based on the length of the array:
    //MAKE SURE TO REMEMBER THAT AFTER MAKING ONE OF THE PLAYER BOXES YOU STILL HAVE TO ADD IT TO THE DOM
    //Case 1:
    //Player 1 goes into row 1 as a big
    //
    //Case 2: 
    //Player 1 goes into row 1 as a big
    //Player 2 goes into row 2 as a big
    //
    //Case 3:
    //Player 1 and 2 go into row 1 as a small
    //Player 3 goes into row 2, check boolean value on whether or not it should be a big or a small
    //
    //Case 4: 
    //Players 1 and 2 go into row 1 as a small
    //Players 3 and 4 go into row 2 as a small
    //
    //End switch statement

    switch(casters.length){
        case 1:
            const caster1_1 = buildPlayerBox(casters[0],"caster1","smallWide");
            boxRow1.appendChild(caster1_1);
            break;
        case 2:
            const caster1_2 = buildPlayerBox(casters[0],"caster1","smallWide");
            const caster2_2 = buildPlayerBox(casters[1],"caster2","smallWide");
            boxRow1.appendChild(caster1_2);
            boxRow2.appendChild(caster2_2);
            break;
        case 3:
            const caster1_3 = buildPlayerBox(casters[0],"caster1","small");
            const caster2_3 = buildPlayerBox(casters[1],"caster2","small");
            const caster3_3 = buildPlayerBox(casters[2],"caster3",expandCaster?"smallWide":"small");
            boxRow1.appendChild(caster1_3);
            boxRow1.appendChild(caster2_3);
            boxRow2.appendChild(caster3_3);
            break;
        case 4:
            const caster1_4 = buildPlayerBox(casters[0],"caster1","small");
            const caster2_4 = buildPlayerBox(casters[1],"caster2","small");
            const caster3_4 = buildPlayerBox(casters[2],"caster3","small");
            const caster4_4 = buildPlayerBox(casters[3],"caster4","small");
            boxRow1.appendChild(caster1_4);
            boxRow1.appendChild(caster2_4);
            boxRow2.appendChild(caster3_4);
            boxRow2.appendChild(caster4_4);
            break;



    }
    //also at this point you are done, since you have as you went added each of the components to their nodes. All you have left now to do is:
    //
    //return the root node
    return casterRoot;

}

//Hopefully the above lines are enough to make everything I need here to work. Parsing the data from the thing will happen in the dashboard and not the graphics section so my part here is easy

//Create a replicant that represents all of the data that we need

//Define event listener for a change from the replicant. Will be very simple here, just is: 
//on change, execute processUpdate with parameter of replicant.value

//we will define the data object like this below example. This example can also be used to text our program which will be useful to make sure this all works before we add the nodecg dashboard to the fucker

let sampleData = {
    players:[
        {
            pronouns: "he/they",
            name: "EdgeTE",
            discordID: "317475187391987713"
        },
        {
            pronouns: "he/they",
            name: "EdgeTE",
            discordID: 1248298
        }
    ],
    casters:[
        {
            pronouns: "he/they",
            name: "EdgeTE",
            discordID: "317475187391987713"
        }, 
        {
            pronouns: "he/they",
            name: "EdgeTE",
            discordID: "317475187391987713"
        },
        {
            pronouns: "he/they",
            name: "EdgeTE",
            discordID: "317475187391987713"
        }
    ],
    expand:true
}




//Replicant 
const state = nodecg.Replicant("state");
state.on("change", (newVal, oldVal) => {
  console.log(newVal);
  if (newVal != undefined) {
    processUpdate(newVal);
  }
});